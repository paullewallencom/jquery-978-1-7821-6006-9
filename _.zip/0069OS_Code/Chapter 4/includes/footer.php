    <p class="fullSite"><a class="fullSiteLink" rel="external" href="<?=$fullSiteLinkHref?>">View Full Site</a></p> 
 