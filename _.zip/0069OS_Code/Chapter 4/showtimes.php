    <li data-role="list-divider">Opening This Week</li>
    <li>
        <a href="movie.php?id=193818">
            <img src="images/darkknightrises.jpeg">
            <h3>Dark Knight Rises</h3>
            <p>PG-13 - 2h 20m<br/><strong>Showtimes:</strong> 12:00 - 12:30 - 1:00 - 1:30 - 3:30 - 4:00 - 4:30 - 7:00 - 7:15 - 7:30 - 7:45 - 8:00 - 10:30 - 10:45</p>
        </a>
    </li>
    <li>
        <a href="moviedetails.php?id=193812">
            <img src="images/iceagecontinentaldrift.jpeg">
            <h3>Ice Age 4: Continental Drift</h3>
            <p>PG - 1h 56m<br/><strong>Showtimes:</strong> 10:20 AM - 10:50 AM - 12:40 - 1:15 - 3:00 - 7:00 - 7:30 - 9:30</p>
        </a>
    </li>
    <li data-role="list-divider">Also in Theaters</li>
    <li>
        <a href="moviedetails.php?id=194103">
            <img src="images/savages.jpeg">
            <h3>Savages</h3>
            <p>R - 7/6/2012<br/><strong>Showtimes:</strong> 10:05 AM - 1:05 - 4:05 - 7:05 - 10:15</p>
        </a>
    </li>
    <li>
        <a href="moviedetails.php?id=194226">
            <img src="images/katyperrypartofme.jpeg">
            <h3>Katy Perry: Part of Me</h3>
            <p>PG - 7/5/2012<br/><strong>Showtimes:</strong> 10:05 AM - 1:05 - 4:05 - 7:05 - 10:15</p>
        </a>
    </li>
    <li>
        <a href="moviedetails.php?id=193807">
            <img src="images/amazingspiderman.jpeg">
            <h3>Amazing Spider-Man</h3>
            <p>PG-13 - 7/5/2012<br/><strong>Showtimes:</strong> 10:00 AM - 1:00 - 4:00 - 7:00 - 10:00</p>
        </a>
    </li>
