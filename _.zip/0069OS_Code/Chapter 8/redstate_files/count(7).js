var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"showReactions": true, "text": {"and": "and", "reactions": {"zero": "", "multiple": "", "one": ""}, "comments": {"zero": "0", "multiple": "{num}", "one": "1"}}, "counts": [{"reactions": 0, "uid": 60, "comments": 1}, {"reactions": 0, "uid": 61, "comments": 7}, {"reactions": 170, "uid": 62, "comments": 60}, {"reactions": 0, "uid": 63, "comments": 7}, {"reactions": 0, "uid": 64, "comments": 5}, {"reactions": 3, "uid": 65, "comments": 8}, {"reactions": 0, "uid": 66, "comments": 44}]});
}
