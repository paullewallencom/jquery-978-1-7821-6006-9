var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"showReactions": true, "text": {"and": "and", "reactions": {"zero": "", "multiple": "", "one": ""}, "comments": {"zero": "0", "multiple": "{num}", "one": "1"}}, "counts": [{"reactions": 0, "uid": 24, "comments": 3}, {"reactions": 0, "uid": 25, "comments": 1}, {"reactions": 0, "uid": 26, "comments": 0}, {"reactions": 0, "uid": 27, "comments": 56}, {"reactions": 0, "uid": 20, "comments": 0}, {"reactions": 0, "uid": 21, "comments": 9}, {"reactions": 0, "uid": 22, "comments": 1}, {"reactions": 0, "uid": 23, "comments": 2}, {"reactions": 1, "uid": 28, "comments": 1}, {"reactions": 0, "uid": 29, "comments": 16}]});
}
