var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"showReactions": true, "text": {"and": "and", "reactions": {"zero": "", "multiple": "", "one": ""}, "comments": {"zero": "0", "multiple": "{num}", "one": "1"}}, "counts": [{"reactions": 0, "uid": 11, "comments": 8}, {"reactions": 0, "uid": 10, "comments": 4}, {"reactions": 0, "uid": 13, "comments": 4}, {"reactions": 0, "uid": 12, "comments": 4}, {"reactions": 48, "uid": 15, "comments": 2}, {"reactions": 0, "uid": 14, "comments": 2}, {"reactions": 0, "uid": 17, "comments": 4}, {"reactions": 0, "uid": 16, "comments": 0}, {"reactions": 0, "uid": 19, "comments": 1}, {"reactions": 0, "uid": 18, "comments": 0}]});
}
