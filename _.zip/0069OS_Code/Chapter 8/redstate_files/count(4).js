var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"showReactions": true, "text": {"and": "and", "reactions": {"zero": "", "multiple": "", "one": ""}, "comments": {"zero": "0", "multiple": "{num}", "one": "1"}}, "counts": [{"reactions": 20, "uid": 39, "comments": 36}, {"reactions": 0, "uid": 38, "comments": 0}, {"reactions": 0, "uid": 33, "comments": 13}, {"reactions": 1, "uid": 32, "comments": 1}, {"reactions": 0, "uid": 31, "comments": 4}, {"reactions": 0, "uid": 30, "comments": 0}, {"reactions": 0, "uid": 37, "comments": 1}, {"reactions": 13, "uid": 36, "comments": 83}, {"reactions": 0, "uid": 35, "comments": 3}, {"reactions": 0, "uid": 34, "comments": 1}]});
}
