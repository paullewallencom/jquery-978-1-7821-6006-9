

document.write(' \
<style type="text/css" media="screen">\
	 .dsq-widget ul.dsq-widget-list {\
	 padding: 0;\
	 margin: 0;\
	 text-align: left;\
	 }\
	 img.dsq-widget-avatar {\
	 width: 24px;\
	 height: 24px;\
	 border: 0px;\
	 margin: 0px;\
	 padding: 0px 3px 3px 0px;\
	 float: left;\
	 }\
	 a.dsq-widget-user {\
	 font-weight: bold;\
	 }\
	 a.dsq-widget-thread {\
	 font-weight: bold;\
	 }\
	 p.dsq-widget-meta {\
	 clear: both;\
	 font-size: 80%;\
	 padding: 0;\
	 margin: 0;\
	 }\
	 li.dsq-widget-item {\
	 margin: 15px 0;\
	 list-style-type: none;\
	 clear: both;\
	 }\
	 span.dsq-widget-clout {\
	 padding: 0 2px;\
	 background-color: #ff7300;\
	 color: #fff;\
	 }\
	 table.dsq-widget-horiz td {\
	 padding-right: 15px;\
	 }\
	 .dsq-widget-comment p {\
	 display: inline;\
	 }\
	 </style>\
	 <ul class="dsq-widget-list">\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-f17160cd2b487d2c719c20cde5a670e6/">garfieldjl</a>\
	 <span class="dsq-widget-comment"><p>I don\'t think 2008 would have turned out much different, Huckabee\'s supporters were more apt to...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.redstate.com/garfieldjl/2012/11/24/suggestion-for-changes-to-primaries/">Suggestion for Changes to Primaries</a>&nbsp;&middot;&nbsp;<a href="http://www.redstate.com/garfieldjl/2012/11/24/suggestion-for-changes-to-primaries/#comment-718326666">7 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-049a632efba268d49b6a861759a4268a/">exitsfunnel</a>\
	 <span class="dsq-widget-comment"><p>This is a pretty good diary I think. I\'m very close to this issue. I live in a community that is...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.redstate.com/dcacklam/2012/11/24/an-issue-thats-sinking-us-immigration/">An issue that&#8217;s sinking us: Immigration</a>&nbsp;&middot;&nbsp;<a href="http://www.redstate.com/dcacklam/2012/11/24/an-issue-thats-sinking-us-immigration/#comment-718323589">15 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-0bc58258e6f3c040a65fa2bfc9d0c907/">1stRichard</a>\
	 <span class="dsq-widget-comment"><p>And Subject to the jurisdiction thereof, the Jurisdiction Clause should be discussed but it seems...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.redstate.com/dcacklam/2012/11/24/an-issue-thats-sinking-us-immigration/">An issue that&#8217;s sinking us: Immigration</a>&nbsp;&middot;&nbsp;<a href="http://www.redstate.com/dcacklam/2012/11/24/an-issue-thats-sinking-us-immigration/#comment-718323241">16 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-76bd11c9b1ed5949c850d1ebdc47f1c0/">JKnight</a>\
	 <span class="dsq-widget-comment"><p>An interesting proposal for primaries. Variations of this system are used in many countries...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.redstate.com/garfieldjl/2012/11/24/suggestion-for-changes-to-primaries/">Suggestion for Changes to Primaries</a>&nbsp;&middot;&nbsp;<a href="http://www.redstate.com/garfieldjl/2012/11/24/suggestion-for-changes-to-primaries/#comment-718322859">17 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-381cbd971176e0872c37e705e882c9be/">gmat</a>\
	 <span class="dsq-widget-comment"><p>People that stick to science-over-all are missing out on a very rich side of human life. Magic,...</p></span>\
	 <p class="dsq-widget-meta"><a href="https://www.redstate.com/2012/11/20/i-believe-and-am-thankful/">I Believe and Am Thankful</a>&nbsp;&middot;&nbsp;<a href="https://www.redstate.com/2012/11/20/i-believe-and-am-thankful/#comment-718321830">20 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-f17160cd2b487d2c719c20cde5a670e6/">garfieldjl</a>\
	 <span class="dsq-widget-comment"><p>Rick Perry had a good record, but he wasn\'t even close to being our best candidate, it could be...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.redstate.com/joshleguern/2012/11/24/yes-we-do-need-to-start-talking-about-2016/">Yes, We DO Need to Start Talking About 2016</a>&nbsp;&middot;&nbsp;<a href="http://www.redstate.com/joshleguern/2012/11/24/yes-we-do-need-to-start-talking-about-2016/#comment-718320268">24 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-049a632efba268d49b6a861759a4268a/">exitsfunnel</a>\
	 <span class="dsq-widget-comment"><p>I assume that you meant to name Scalia there instead of Alito. Or does Alito have some health...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.redstate.com/colincarr/2012/11/23/reasonable-socially-conservative-positions-on-three-issues/">Reasonable Socially Conservative Positions on Three Issues</a>&nbsp;&middot;&nbsp;<a href="http://www.redstate.com/colincarr/2012/11/23/reasonable-socially-conservative-positions-on-three-issues/#comment-718317335">32 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-23bde9ebd4305abe4f10560be881b203/">Dave_A</a>\
	 <span class="dsq-widget-comment"><p>Well, the Bible is quite unequivocal on the subject, which is why those churches which are more...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.redstate.com/colincarr/2012/11/23/reasonable-socially-conservative-positions-on-three-issues/">Reasonable Socially Conservative Positions on Three Issues</a>&nbsp;&middot;&nbsp;<a href="http://www.redstate.com/colincarr/2012/11/23/reasonable-socially-conservative-positions-on-three-issues/#comment-718315719">36 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-4965052ffc53f745343bab61a5f8aee7/">ColdWarrior</a>\
	 <span class="dsq-widget-comment"><p>Better watch out. The libertarians are not going to go away and they are trying to take over the...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.redstate.com/joshleguern/2012/11/24/yes-we-do-need-to-start-talking-about-2016/">Yes, We DO Need to Start Talking About 2016</a>&nbsp;&middot;&nbsp;<a href="http://www.redstate.com/joshleguern/2012/11/24/yes-we-do-need-to-start-talking-about-2016/#comment-718315423">37 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-381cbd971176e0872c37e705e882c9be/">gmat</a>\
	 <span class="dsq-widget-comment"><p>This a very concise presentation of a well thought out policy. I\'m going to print it and show it...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.redstate.com/dcacklam/2012/11/24/an-issue-thats-sinking-us-immigration/">An issue that&#8217;s sinking us: Immigration</a>&nbsp;&middot;&nbsp;<a href="http://www.redstate.com/dcacklam/2012/11/24/an-issue-thats-sinking-us-immigration/#comment-718315126">38 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-8200e2e850224e4cea691cdc3ad0da2d/">Jim_Riggs</a>\
	 <span class="dsq-widget-comment"><p>I don\'t believe Ran Paul could get 40% of the vote in a general election.</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.redstate.com/joshleguern/2012/11/24/yes-we-do-need-to-start-talking-about-2016/">Yes, We DO Need to Start Talking About 2016</a>&nbsp;&middot;&nbsp;<a href="http://www.redstate.com/joshleguern/2012/11/24/yes-we-do-need-to-start-talking-about-2016/#comment-718314768">39 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-649927d37f4afecb602b470b820de6d5/">synergist777</a>\
	 <span class="dsq-widget-comment"><p>"Such is life when you have 3rd-world skills in a 1st world economy..." And, unless something is...</p></span>\
	 <p class="dsq-widget-meta"><a href="https://www.redstate.com/nedryun/2012/11/21/i-think-sometimes-we-are-truly-a-stupid-movement/">I Think Sometimes We are Truly a Stupid Movement</a>&nbsp;&middot;&nbsp;<a href="https://www.redstate.com/nedryun/2012/11/21/i-think-sometimes-we-are-truly-a-stupid-movement/#comment-718313339">43 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-23bde9ebd4305abe4f10560be881b203/">Dave_A</a>\
	 <span class="dsq-widget-comment"><p>That\'s why it works... You can also push it down further, and \'state-level\' most of the federal...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.redstate.com/colincarr/2012/11/23/reasonable-socially-conservative-positions-on-three-issues/">Reasonable Socially Conservative Positions on Three Issues</a>&nbsp;&middot;&nbsp;<a href="http://www.redstate.com/colincarr/2012/11/23/reasonable-socially-conservative-positions-on-three-issues/#comment-718312837">44 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-c7217b04fe11f374f9a6737901025606/">civil truth</a>\
	 <span class="dsq-widget-comment"><p>Another thoughtful piece by you, Dave trying to sort out the Senate conundrum. However, I think...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.redstate.com/davenj1/2012/11/24/the-old-senate-versus-the-new-senate/">The Old Senate Versus the New Senate</a>&nbsp;&middot;&nbsp;<a href="http://www.redstate.com/davenj1/2012/11/24/the-old-senate-versus-the-new-senate/#comment-718312407">45 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-23bde9ebd4305abe4f10560be881b203/">Dave_A</a>\
	 <span class="dsq-widget-comment"><p>FMA can\'t pass though. Neither can Personhood.... I\'m not saying I don\'t want it to pass - in...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.redstate.com/colincarr/2012/11/23/reasonable-socially-conservative-positions-on-three-issues/">Reasonable Socially Conservative Positions on Three Issues</a>&nbsp;&middot;&nbsp;<a href="http://www.redstate.com/colincarr/2012/11/23/reasonable-socially-conservative-positions-on-three-issues/#comment-718312351">45 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-23bde9ebd4305abe4f10560be881b203/">Dave_A</a>\
	 <span class="dsq-widget-comment"><p>Perry/Walker. Perry/Rubio. Walker/Rubio. The headliner needs to be a governor, and of our...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.redstate.com/joshleguern/2012/11/24/yes-we-do-need-to-start-talking-about-2016/">Yes, We DO Need to Start Talking About 2016</a>&nbsp;&middot;&nbsp;<a href="http://www.redstate.com/joshleguern/2012/11/24/yes-we-do-need-to-start-talking-about-2016/#comment-718309812">52 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-23bde9ebd4305abe4f10560be881b203/">Dave_A</a>\
	 <span class="dsq-widget-comment"><p>The \'Media\' didn\'t keep us divided - WE divided ourselves. Rather than coalescing around a single...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.redstate.com/joshleguern/2012/11/24/yes-we-do-need-to-start-talking-about-2016/">Yes, We DO Need to Start Talking About 2016</a>&nbsp;&middot;&nbsp;<a href="http://www.redstate.com/joshleguern/2012/11/24/yes-we-do-need-to-start-talking-about-2016/#comment-718309340">53 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-f17160cd2b487d2c719c20cde5a670e6/">garfieldjl</a>\
	 <span class="dsq-widget-comment"><p>Honestly I think if we had McCain as our nominee this time around with the same VP pick, we would...</p></span>\
	 <p class="dsq-widget-meta"><a href="https://www.redstate.com/nedryun/2012/11/21/i-think-sometimes-we-are-truly-a-stupid-movement/">I Think Sometimes We are Truly a Stupid Movement</a>&nbsp;&middot;&nbsp;<a href="https://www.redstate.com/nedryun/2012/11/21/i-think-sometimes-we-are-truly-a-stupid-movement/#comment-718308867">54 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-508faf6eeda59a95805cf307afac7d18/">Colin Carr</a>\
	 <span class="dsq-widget-comment"><p>I like the let-the-states-decide stance quite a bit. I don\'t think we would lose any significant...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.redstate.com/colincarr/2012/11/23/reasonable-socially-conservative-positions-on-three-issues/">Reasonable Socially Conservative Positions on Three Issues</a>&nbsp;&middot;&nbsp;<a href="http://www.redstate.com/colincarr/2012/11/23/reasonable-socially-conservative-positions-on-three-issues/#comment-718307667">58 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-23bde9ebd4305abe4f10560be881b203/">Dave_A</a>\
	 <span class="dsq-widget-comment"><p>I would contend that our best candidate, from the Primaries, was Perry. And that his more...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.redstate.com/dcacklam/2012/11/24/an-issue-thats-sinking-us-immigration/">An issue that&#8217;s sinking us: Immigration</a>&nbsp;&middot;&nbsp;<a href="http://www.redstate.com/dcacklam/2012/11/24/an-issue-thats-sinking-us-immigration/#comment-718307279">59 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-508faf6eeda59a95805cf307afac7d18/">Colin Carr</a>\
	 <span class="dsq-widget-comment"><p>I hope Marco Rubio, Bobby Jindal, Kelly Ayotte, Rand Paul, and Paul Ryan are our main candidates...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.redstate.com/joshleguern/2012/11/24/yes-we-do-need-to-start-talking-about-2016/">Yes, We DO Need to Start Talking About 2016</a>&nbsp;&middot;&nbsp;<a href="http://www.redstate.com/joshleguern/2012/11/24/yes-we-do-need-to-start-talking-about-2016/#comment-718306627">1 hour ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-60413fd1faa30eb4bc3ae3d4e4b88813/">norris</a>\
	 <span class="dsq-widget-comment"><p>What happened with fast and furious secret investigations and no prosecutions , this will be no...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.redstate.com/scipio62/2012/11/24/benghazi-terror-investigation-going-about-as-expected/">Benghazi Terror Investigation Going About As Expected</a>&nbsp;&middot;&nbsp;<a href="http://www.redstate.com/scipio62/2012/11/24/benghazi-terror-investigation-going-about-as-expected/#comment-718306504">1 hour ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-5addc429b39957a9752b0f32f6a4019c/">fightnright</a>\
	 <span class="dsq-widget-comment"><p>oh, I\'ve always thought that the Herbert Marcuse concept from Repressive Tolerance: "Liberating...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.redstate.com/2012/11/23/barack-obama-thinking-of-backing-off-of-no-corporate-money-for-inauguration/">Barack Obama &#8216;thinking&#8217; of backing off of no-corporate-money for Inauguration.</a>&nbsp;&middot;&nbsp;<a href="http://www.redstate.com/2012/11/23/barack-obama-thinking-of-backing-off-of-no-corporate-money-for-inauguration/#comment-718304303">1 hour ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-23bde9ebd4305abe4f10560be881b203/">Dave_A</a>\
	 <span class="dsq-widget-comment"><p>My mention of the military, was that it\'s the only career path above \'fries with that\' for the...</p></span>\
	 <p class="dsq-widget-meta"><a href="https://www.redstate.com/nedryun/2012/11/21/i-think-sometimes-we-are-truly-a-stupid-movement/">I Think Sometimes We are Truly a Stupid Movement</a>&nbsp;&middot;&nbsp;<a href="https://www.redstate.com/nedryun/2012/11/21/i-think-sometimes-we-are-truly-a-stupid-movement/#comment-718303317">1 hour ago</a></p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-user" href="http://disqus.com/redstate-f17160cd2b487d2c719c20cde5a670e6/">garfieldjl</a>\
	 <span class="dsq-widget-comment"><p>The problem is we didn\'t have a candidate that was able to voice a plan concerning immigration...</p></span>\
	 <p class="dsq-widget-meta"><a href="http://www.redstate.com/dcacklam/2012/11/24/an-issue-thats-sinking-us-immigration/">An issue that&#8217;s sinking us: Immigration</a>&nbsp;&middot;&nbsp;<a href="http://www.redstate.com/dcacklam/2012/11/24/an-issue-thats-sinking-us-immigration/#comment-718298803">1 hour ago</a></p>\
	 </li>\
	 </ul>\
');
