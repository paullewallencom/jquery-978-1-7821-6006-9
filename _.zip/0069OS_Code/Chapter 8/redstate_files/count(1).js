var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"showReactions": true, "text": {"and": "and", "reactions": {"zero": "", "multiple": "", "one": ""}, "comments": {"zero": "0", "multiple": "{num}", "one": "1"}}, "counts": [{"reactions": 0, "uid": 1, "comments": 5}, {"reactions": 50, "uid": 0, "comments": 14}, {"reactions": 0, "uid": 3, "comments": 12}, {"reactions": 0, "uid": 2, "comments": 1}, {"reactions": 0, "uid": 5, "comments": 2}, {"reactions": 0, "uid": 4, "comments": 1}, {"reactions": 0, "uid": 7, "comments": 3}, {"reactions": 0, "uid": 6, "comments": 23}, {"reactions": 0, "uid": 9, "comments": 0}, {"reactions": 0, "uid": 8, "comments": 2}]});
}
