var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"showReactions": true, "text": {"and": "and", "reactions": {"zero": "", "multiple": "", "one": ""}, "comments": {"zero": "0", "multiple": "{num}", "one": "1"}}, "counts": [{"reactions": 0, "uid": 48, "comments": 2}, {"reactions": 0, "uid": 49, "comments": 0}, {"reactions": 0, "uid": 46, "comments": 2}, {"reactions": 0, "uid": 47, "comments": 0}, {"reactions": 0, "uid": 44, "comments": 0}, {"reactions": 1, "uid": 45, "comments": 4}, {"reactions": 0, "uid": 42, "comments": 5}, {"reactions": 0, "uid": 43, "comments": 1}, {"reactions": 0, "uid": 40, "comments": 10}, {"reactions": 0, "uid": 41, "comments": 1}]});
}
