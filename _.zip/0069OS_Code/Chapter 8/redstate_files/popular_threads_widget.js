

document.write(' \
<style type="text/css" media="screen">\
	 .dsq-widget ul.dsq-widget-list {\
	 padding: 0;\
	 margin: 0;\
	 text-align: left;\
	 }\
	 img.dsq-widget-avatar {\
	 border: 0px;\
	 margin: 0px;\
	 padding: 0px 3px 3px 0px;\
	 float: left;\
	 }\
	 a.dsq-widget-user {\
	 font-weight: bold;\
	 }\
	 a.dsq-widget-thread {\
	 font-weight: bold;\
	 }\
	 p.dsq-widget-meta {\
	 clear: both;\
	 font-size: 80%;\
	 padding: 0;\
	 margin: 0;\
	 }\
	 li.dsq-widget-item {\
	 margin: 15px 0;\
	 list-style-type: none;\
	 clear: both;\
	 }\
	 span.dsq-widget-clout {\
	 padding: 0 2px;\
	 background-color: #ff7300;\
	 color: #fff;\
	 }\
	 table.dsq-widget-horiz td {\
	 padding-right: 15px;\
	 }\
	 .dsq-widget-comment p {\
	 display: inline;\
	 }\
	 </style>\
	 <ul class="dsq-widget-list">\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="http://www.redstate.com/joshleguern/2012/11/24/yes-we-do-need-to-start-talking-about-2016/">Yes, We DO Need to Start Talking About 2016</a>\
	 <p class="dsq-widget-meta">12 comments &middot; 26 minutes ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="http://www.redstate.com/2012/11/23/i-think-cnn-com-badly-mischaracterizes-this-site/">I Think CNN.com Badly Mischaracterizes This Site</a>\
	 <p class="dsq-widget-meta">63 comments &middot; 1 hour ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="https://www.redstate.com/2012/11/20/i-believe-and-am-thankful/">I Believe and Am Thankful</a>\
	 <p class="dsq-widget-meta">225 comments &middot; 22 minutes ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="http://www.redstate.com/colincarr/2012/11/23/reasonable-socially-conservative-positions-on-three-issues/">Reasonable Socially Conservative Positions on Three Issues</a>\
	 <p class="dsq-widget-meta">23 comments &middot; 34 minutes ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="http://www.redstate.com/dcacklam/2012/11/24/an-issue-thats-sinking-us-immigration/">An issue that&#8217;s sinking us: Immigration</a>\
	 <p class="dsq-widget-meta">5 comments &middot; 17 minutes ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="http://www.redstate.com/ntrepid/2012/11/24/now-watching-the-american-demise-on-mute-an-ntrepid-ramble/">Now Watching the American Demise on Mute: An Ntrepid Ramble</a>\
	 <p class="dsq-widget-meta">3 comments &middot; 4 hours ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="http://www.redstate.com/rolandlind/2012/11/22/how-to-win-the-youthblacklatinofill-in-the-blank-vote-step-1/">How to win the (youth/black/latino/fill in the blank) vote, Step 1.</a>\
	 <p class="dsq-widget-meta">56 comments &middot; 20 hours ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="https://www.redstate.com/nedryun/2012/11/21/i-think-sometimes-we-are-truly-a-stupid-movement/">I Think Sometimes We are Truly a Stupid Movement</a>\
	 <p class="dsq-widget-meta">83 comments &middot; 44 minutes ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="http://www.redstate.com/2012/11/20/ronald-reagan-and-what-i-got-wrong/">Ronald Reagan and What I Got Wrong</a>\
	 <p class="dsq-widget-meta">118 comments &middot; 3 days ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="http://www.redstate.com/2012/11/23/barack-obama-thinking-of-backing-off-of-no-corporate-money-for-inauguration/">Barack Obama &#8216;thinking&#8217; of backing off of no-corporate-money for Inauguration.</a>\
	 <p class="dsq-widget-meta">15 comments &middot; 1 hour ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="http://www.redstate.com/reddog53/2012/11/24/im-not-interest-in-rand-paul-or-anyone-else-right-now/">I&#8217;m Not Interested In Rand Paul &#8212; Or Anyone Else &#8212; Right Now</a>\
	 <p class="dsq-widget-meta">1 comment &middot; 2 hours ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="http://www.redstate.com/scipio62/2012/11/23/lets-talk-about-abortion/">Let&#8217;s Talk About Abortion</a>\
	 <p class="dsq-widget-meta">17 comments &middot; 23 hours ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="https://www.redstate.com/2012/11/12/no/">No.</a>\
	 <p class="dsq-widget-meta">310 comments &middot; 2 days ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="https://www.redstate.com/2012/11/09/it-is-time-to-throw-the-social-conservatives-out-of-the-gop/">It Is Time to Throw the Social Conservatives Out of the GOP</a>\
	 <p class="dsq-widget-meta">328 comments &middot; 3 days ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="http://www.redstate.com/jeffs65/2012/11/24/israel-gets-no-respect/">Israel Gets No Respect…</a>\
	 <p class="dsq-widget-meta">2 comments &middot; 5 hours ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="http://www.redstate.com/2012/11/13/can-we-replace-john-boehner-with-paul-ryan/">Can We Replace John Boehner With Paul Ryan?</a>\
	 <p class="dsq-widget-meta">186 comments &middot; 3 days ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="https://www.redstate.com/2012/11/07/status-quo-ante/">Status Quo Ante</a>\
	 <p class="dsq-widget-meta">328 comments &middot; 2 weeks ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="https://www.redstate.com/2012/11/20/note-to-john-podhoretz-um-heck-yeah-we-are-the-latter/">Um . . . Heck Yeah We Are the Latter</a>\
	 <p class="dsq-widget-meta">57 comments &middot; 2 days ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="http://www.redstate.com/coolhand/2012/11/23/was-election-a-tipping-point/">Was Election a Tipping-Point?</a>\
	 <p class="dsq-widget-meta">8 comments &middot; 6 hours ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="http://www.redstate.com/chris_chocola_cfg/2012/11/21/on-the-gop-establishment-and-primaries/">On the GOP Establishment And Primaries</a>\
	 <p class="dsq-widget-meta">36 comments &middot; 7 hours ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="https://www.redstate.com/2012/11/07/to-beat-the-president/">To Beat the President</a>\
	 <p class="dsq-widget-meta">282 comments &middot; 2 weeks ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="http://www.redstate.com/2012/11/13/is-it-time-to-roll-up-the-welcome-mat-here/">Is It Time to Roll Up the Welcome Mat Here?</a>\
	 <p class="dsq-widget-meta">161 comments &middot; 1 week ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="http://www.redstate.com/2012/11/11/from-november-8-2011-see-i-told-you-so/">From November 8, 2011: See, I Told You So</a>\
	 <p class="dsq-widget-meta">196 comments &middot; 1 week ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="https://www.redstate.com/2012/11/08/we-forget/">We Forget</a>\
	 <p class="dsq-widget-meta">259 comments &middot; 2 weeks ago</p>\
	 </li>\
	 <li class="dsq-widget-item">\
	 <a class="dsq-widget-thread" href="https://www.redstate.com/2012/11/09/campaign-sources-the-romney-campaign-was-a-consultant-con-job/">Campaign Sources: The Romney Campaign was a Consultant Con Job</a>\
	 <p class="dsq-widget-meta">219 comments &middot; 1 week ago</p>\
	 </li>\
	 </ul>\
');
