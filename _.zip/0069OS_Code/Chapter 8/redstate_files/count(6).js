var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"showReactions": true, "text": {"and": "and", "reactions": {"zero": "", "multiple": "", "one": ""}, "comments": {"zero": "0", "multiple": "{num}", "one": "1"}}, "counts": [{"reactions": 32, "uid": 59, "comments": 10}, {"reactions": 0, "uid": 58, "comments": 3}, {"reactions": 0, "uid": 55, "comments": 3}, {"reactions": 0, "uid": 54, "comments": 1}, {"reactions": 0, "uid": 57, "comments": 8}, {"reactions": 0, "uid": 56, "comments": 27}, {"reactions": 0, "uid": 51, "comments": 3}, {"reactions": 0, "uid": 50, "comments": 3}, {"reactions": 0, "uid": 53, "comments": 2}, {"reactions": 0, "uid": 52, "comments": 1}]});
}
