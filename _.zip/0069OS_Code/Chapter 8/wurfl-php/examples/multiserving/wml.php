<?php echo '<?xml version="1.0"?>'; ?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">

<wml>
    <card id="w" title="Hello World">
        <p>
            <img src="images/logo.wbmp" alt="WURFL" /> 
            <br/>
            <br/><b>Hello From WML </b>
        </p>
    </card>
</wml>
