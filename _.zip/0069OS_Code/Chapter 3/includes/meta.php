<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
<link href='http://fonts.googleapis.com/css?family=Marvel' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="jquery.mobile-1.1.1.min.css" />
<link rel="stylesheet" href="css/custom.css" />
<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/jquery.cookie.js"></script> 
<script src="js/jquery.validate.min.js"></script>
<script src="js/global.js"></script>
<script src="js/jquery.mobile-1.1.1.min.js"></script>
<title><?=$documentTitle?></title> 
