	<div data-role="footer">
		<h4>Call Us: <a href="+18167816500">(816) 781-6500</a></h4>
	</div><!-- /footer -->
    <p class="fullSite"><a class="fullSiteLink" rel="external" href="<?=$fullSiteLinkHref?>">View Full Site</a></p>
    <p class="copyright">A <a href="http://roughlybrilliant.com">Roughly Brilliant</a> Production &copy; 2012</p>
